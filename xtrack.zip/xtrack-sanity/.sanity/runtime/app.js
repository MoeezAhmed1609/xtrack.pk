
// This file is auto-generated on 'sanity dev'
// Modifications to this file is automatically discarded
import {renderStudio} from "sanity"
import studioConfig from "../../sanity.config.js"

renderStudio(
  document.getElementById("sanity"),
  studioConfig,
  false
)
