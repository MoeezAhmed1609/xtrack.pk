import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'ke3vv5hk',
    dataset: 'production'
  }
})
