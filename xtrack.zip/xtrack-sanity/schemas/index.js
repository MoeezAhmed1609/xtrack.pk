import banner from "./Banner"
import discount from "./Discount"
import usage from "./Usage"
import blogs from './Blog'
import webtitle from "./WebTitle"

export const schemaTypes = [banner , discount , usage , blogs , webtitle]