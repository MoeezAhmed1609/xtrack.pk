import React from 'react'

const deliveryinformation = () => {
  return (
    <div className='container my-5'>
      <div className='row'>
        <div className='col-12 text-center'>
            <h3 className='fw-bold text-uppercase'>Delievery Information</h3>
        </div>
        <div className='col-12'>
          <div className=''>
            <h5 className='text-uppercase fw-bold'>Heading</h5>
            <p className='text-small ps-2'>Paragraph</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default deliveryinformation